function agregarP(palabra) {
    return palabra.replace(/[aeiou]/g, letra => letra + 'p' + letra);
}

const fraseEntrada = "aidan ondicol es de la tecnica 5";
const fraseSalida = agregarP(fraseEntrada);

console.log("Entrada:", fraseEntrada);
console.log("Salida:", fraseSalida);